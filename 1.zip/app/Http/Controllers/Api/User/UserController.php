<?php

namespace App\Http\Controllers\Api\User;

//Helpers and Class
use App\Exceptions\ApiValidatorException;
use Validator;
//Models
use Carbon\Carbon;
use App\Models\User;
//use App\Models\Passport\Token;
/*use App\Models\DeviceLogger;
use App\Models\Device;*/
//Class
use MongoDB\BSON\UTCDateTime;
use Illuminate\Http\Request;
use App\Http\Traits\ResponseApi;
use App\Http\Facades\Utilities;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
//use Illuminate\Support\Facades\Mail;
//use App\Mail\NotificationRegister;

use Auth;

class UserController extends Controller
{
    use ResponseApi;
    public function register (Request $request) 
    {
        try {
            $input = $request->all();
            $rules = [
                'email' => 'required|string',
                'id' => 'required|string',
                'folio' => 'required|string'
            ];

            $validator = Validator::make($input, $rules);
            if ($validator->fails()) return $this->sendError($validator->errors()->all(),str_replace(':attribute','email',trans('validation.email')), 422);

            $user = User::where('id', $input['id'])->first();
            if (!empty($user))  throw new ApiValidatorException('The email is already in db',trans('user.register.duplicate'), 409);

            $user = new User();
            $user->fill($input);       
            $user->save();

                /*
            dispatch(function () use ($user,$password) {
                $subject='Registro éxitoso Safe App Master';
                Mail::to($user->email)->send(new NotificationRegister($user ,$password, $subject));
            })->afterResponse();*/

            return $this->sendResponse($this->createAccesTokenResponse($user), trans('user.auth.success'));
        } catch (ApiValidatorException $th) {
            return $this->sendError($th->getError(), $th->getMessage(), $th->getCode());
        }
    }

    /**
     * Get User information.
     *
     * @return \Illuminate\Http\Response
     */
    

    public function createAccesTokenResponse($user, $menssage = 'Personal Access Token FUD')
    {

        $tokenResult = $user->createToken($menssage);

        return [
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse($tokenResult->token->expires_at)->toDateTimeString()
        ];
    }

}